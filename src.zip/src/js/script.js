
$(document).ready(function(){
  //  $('.carousel__inner').slick({
  //    speed: 1100,
  //    adaptiveHeight: true,
  //    fade: true,
  //   cssEase: 'linear',
  //    prevArrow: '<button type="button" class="slick-prev"><img src="icons/left.svg"></button>',
  //    nextArrow: '<button type="button" class="slick-next"><img src="icons/right.svg"></button>',
  //    responsive: [
  //     {
  //        breakpoint: 992,
  //        settings: {
  //          dots: true,
  //          arrows: false
  //        }
  //      } 
  //    ] 
  //  });


    $('ul.catalog__tabs').on('click', 'li:not(.catalog__tab_active)', function() {
      $(this)
        .addClass('catalog__tab_active').siblings().removeClass('catalog__tab_active')
        .closest('div.container').find('div.catalog__content').removeClass('catalog__content_active').eq($(this).index()).addClass('catalog__content_active');
    });
    
    function toggleSlide(item) { 
      $(item).each(function(i) {
        $(this).on('click', function(e){
            e.preventDefault();
            $('.catalog-item__content').eq(i).toggleClass('catalog-item__content_active');
            $('.catalog-item__list').eq(i).toggleClass('catalog-item__list_active');
        })
      })
    }

    toggleSlide ('.catalog-item__link');
    toggleSlide ('.catalog-item__back');
    

    
    $('.button ').on('click', function() {
      $('.overlay, #consultation').fadeIn('slow');
  });

 });

      
 



 //$('[data-modal=consultation]').fadeOut();

 // $('[data-modal=consultation]').on('click', function() {
 //    $('.overlay, #consultation').fadeIn();
 // });


//  (function($) {
//   $(function() {
    
//     $('ul.tabs__caption').on('click', 'li:not(.active)', function() {
//       $(this)
//         .addClass('active').siblings().removeClass('active')
//         .closest('div.tabs').find('div.tabs__content').removeClass('active').eq($(this).index()).addClass('active');
//     });
    
//   });
//   })(jQuery);

  // document.querySelector('ul.catalog__tabs').on('click', 'li:not(.catalog__tab_active)', function() {
  //   $(this)
  //     .addClass('catalog__tab_active').siblings().removeClass('catalog__tab_active')
  //     .closest('div.tabs').find('div.tabs__content').removeClass('active').eq($(this).index()).addClass('active');
  // });


  // const slider = tns({
  //   container: '.carousel__inner',
  //   items: 1,
  //   slideBy: 'page',
  //   controls: false,
  //   nav: false,
  //   responsive: {
  //     920: {
  //       edgePadding: 20,
  //       gutter: 20,
  //       items: 1
  //     },
  //     700: {
  //       gutter: 30
  //     },
  //     900: {
  //       items: 3
  //     }
  //   }
  // });

  // document.querySelector('.next').addEventListener('click', function() {
  //   slider.goTo('next'); 
  // })

  // document.querySelector('.prev').addEventListener('click', function() { 
  //   slider.goTo('prev');
  // })

  
  